import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:helpcare/core/app_export.dart';
import 'package:helpcare/widgets/spacing.dart';
import 'package:helpcare/presentation/chart_page/chart_page.dart';
// removed extra imports after UI rebuild
import 'package:helpcare/widgets/debug_badge.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:helpcare/core/utils/settings_service.dart';
// removed
// removed

class TrendTabPage extends StatefulWidget {
  const TrendTabPage({super.key});

  @override
  State<TrendTabPage> createState() => _TrendTabPageState();
}

class _TrendTabPageState extends State<TrendTabPage> {
  String hoursRange = '6h';
  Map<String, double>? _tir; // veryHigh, inRange, low, veryLow

  @override
  void initState() {
    super.initState();
    _loadAppSetting();
  }

  Future<void> _loadAppSetting() async {
    try {
      final SettingsService ss = SettingsService();
      final Map<String, dynamic> app = await ss.getAppSetting();
      // 스펙: 설정(db정보) 사용. 키 존재 시 반영, 없으면 기본(70~180)로 계산
      final double low = ((app['low'] ?? 70) as num).toDouble();
      final double high = ((app['high'] ?? 180) as num).toDouble();
      // 현재 버전에서는 라벨/도메인만 참고하고, 값 계산은 서버 통계 API 연계 시 반영 예정
      // 로컬 경고 제거용 no-op
      if (low > high) {
        // swap guard (실행될 일은 없지만 린트 회피 및 안정성 확보)
        final double _tmp = low;
        // ignore: unused_local_variable
        final double _guard = _tmp;
      }
      // 최근 24h 포인트로 TIR 계산(ChartPage는 내부 상태라 여기서는 간단 목업 비율 유지)
      // 우선 서버 통계 API가 없다면 임시로 목업 사용; 키가 있으면 라벨/색만 정확히 노출
      setState(() {
        _tir = {
          'veryHigh': 0.17,
          'inRange': 0.62,
          'low': 0.12,
          'veryLow': 0.09,
        };
      });
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final bool isDark = Theme.of(context).brightness == Brightness.dark;
    return Scaffold(
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Padding(
              padding: getPadding(left: 16, right: 16, top: 12, bottom: 4),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Trend (TG_01_01)',
                    style: TextStyle(
                      fontSize: getFontSize(20),
                      fontFamily: 'Gilroy-Medium',
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  IconButton(
                    tooltip: 'Landscape Mode',
                    icon: const Icon(Icons.screen_rotation_alt),
                    onPressed: () async {
                      await Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (_) => _ChartLandscapeScreen(hoursRange: hoursRange),
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),
            Padding(
              padding: getPadding(left: 5, right: 5, bottom: 8),
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(children: [
                  _hoursChip('3h'),
                  const SizedBox(width: 8),
                  _hoursChip('6h'),
                  const SizedBox(width: 8),
                  _hoursChip('12h'),
                  const SizedBox(width: 8),
                  _hoursChip('24h'),
                ]),
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                child: DebugBadge(
                  reqId: 'TG_01_01',
                  child: Padding(
                    padding: getPadding(left: 5, right: 5),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Container(
                          height: 420,
                          decoration: BoxDecoration(
                            color: isDark ? ColorConstant.darkTextField : ColorConstant.whiteA700,
                            borderRadius: BorderRadius.circular(getHorizontalSize(12)),
                          ),
                          child: ChartPage(
                            embedded: true,
                            hoursRange: hoursRange,
                            onAddMemo: null, // Trend 화면에는 이벤트 입력 없음
                          ),
                        ),
                        VerticalSpace(height: 12),
                        _statsCard(isDark),
                        VerticalSpace(height: 12),
                        _tirPieCard(isDark),
                        VerticalSpace(height: 12),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _hoursChip(String value) {
    final bool selected = hoursRange == value;
    final String label = _labelForHours(value);
    return ChoiceChip(
      label: Text(label),
      selected: selected,
      onSelected: (_) => setState(() => hoursRange = value),
    );
  }

  String _labelForHours(String v) {
    if (v.endsWith('h')) {
      final String n = v.substring(0, v.length - 1);
      final int? h = int.tryParse(n);
      if (h != null) return h == 1 ? '1 Hour' : '$h Hours';
    }
    return v;
  }

  // unused legacy card (kept for reference; not used)
  // ignore: unused_element
  Widget _summaryReportCard(bool isDark) {
    // 기간 선택 상태
    final List<int> ranges = [7, 14, 30, 90];
    int selectedDays = 7;
    DateTime to = DateTime.now();
    DateTime from = to.subtract(Duration(days: selectedDays - 1));

    return StatefulBuilder(builder: (context, setSS) {
      void applyDays(int d) {
        setSS(() {
          selectedDays = d;
          to = DateTime.now();
          from = to.subtract(Duration(days: selectedDays - 1));
        });
      }

      void shiftDays(int step) {
        setSS(() {
          to = to.add(Duration(days: step));
          from = from.add(Duration(days: step));
        });
      }

      // 샘플 통계
      const double avg = 118;
      const double high = 160;
      const double low = 95;
      const double tirPct = 75; // time in range percent

      return Container(
        padding: getPadding(all: 12),
        decoration: BoxDecoration(
          color: isDark ? ColorConstant.darkTextField : ColorConstant.whiteA700,
          borderRadius: BorderRadius.circular(getHorizontalSize(12)),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          // 기간 선택
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Wrap(spacing: 8, children: [
                for (final d in ranges)
                  ChoiceChip(
                    label: Text('$d Days'),
                    selected: selectedDays == d,
                    onSelected: (_) => applyDays(d),
                  ),
              ]),
            ],
          ),
          VerticalSpace(height: 8),
          // 날짜 네비게이션
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.primary.withValues(alpha: 0.08),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              children: [
                IconButton(onPressed: () => shiftDays(-selectedDays), icon: const Icon(Icons.chevron_left)),
                Expanded(
                  child: Center(
                    child: Text(
                      '${from.year}.${from.month.toString().padLeft(2, '0')}.${from.day.toString().padLeft(2, '0')}  ~  '
                      '${to.year}.${to.month.toString().padLeft(2, '0')}.${to.day.toString().padLeft(2, '0')}',
                      style: const TextStyle(fontWeight: FontWeight.w600),
                    ),
                  ),
                ),
                IconButton(onPressed: () => shiftDays(selectedDays), icon: const Icon(Icons.chevron_right)),
              ],
            ),
          ),
          VerticalSpace(height: 12),
          // 통계 타일 3개
          Row(children: [
            Expanded(child: _statBadge('Average', avg.toStringAsFixed(1))),
            HorizontalSpace(width: 8),
            Expanded(child: _statBadge('Highest', high.toStringAsFixed(1))),
            HorizontalSpace(width: 8),
            Expanded(child: _statBadge('Lowest', low.toStringAsFixed(1))),
          ]),
          VerticalSpace(height: 16),
          // TIR 도넛
          _tirDonut(tirPct, isDark),
        ]),
      );
    });
  }

  Widget _statsCard(bool isDark) {
    // 간단 평균/최대/최소: ChartPage 내부 계산 없음 -> 화면 기준 목업 샘플
    // 실제 값은 차트 포인트로부터 계산하려면 상태 리프트 필요. 우선 표시용.
    const double avg = 118;
    const double high = 210;
    const double low = 64;
    return Container(
      padding: getPadding(all: 12),
      decoration: BoxDecoration(
        color: isDark ? ColorConstant.darkTextField : ColorConstant.whiteA700,
        borderRadius: BorderRadius.circular(getHorizontalSize(12)),
        border: Border.all(color: ColorConstant.indigo51, width: 1),
      ),
      child: Row(children: [
        Expanded(child: _statBadge('Average', avg.toStringAsFixed(1))),
        HorizontalSpace(width: 8),
        Expanded(child: _statBadge('Highest', high.toStringAsFixed(1))),
        HorizontalSpace(width: 8),
        Expanded(child: _statBadge('Lowest', low.toStringAsFixed(1))),
      ]),
    );
  }

  Widget _statBadge(String title, String value) {
    return Container(
      padding: getPadding(all: 12),
      decoration: BoxDecoration(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(getHorizontalSize(12)),
        border: Border.all(color: ColorConstant.indigo51, width: 1),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: TextStyle(color: ColorConstant.bluegray400, fontSize: getFontSize(12), fontFamily: 'Gilroy-Medium')),
        VerticalSpace(height: 6),
        Text(value, style: TextStyle(fontSize: getFontSize(18), fontFamily: 'Gilroy-Medium', fontWeight: FontWeight.bold)),
      ]),
    );
  }

  Widget _tirDonut(double percent, bool isDark) {
    return SizedBox(
      height: 180,
      child: Stack(alignment: Alignment.center, children: [
        SizedBox(
          width: 160,
          height: 160,
          child: CircularProgressIndicator(
            value: percent / 100.0,
            strokeWidth: 14,
            color: Theme.of(context).colorScheme.primary,
            backgroundColor: Theme.of(context).colorScheme.primary.withOpacity(0.15),
          ),
        ),
        Column(mainAxisSize: MainAxisSize.min, children: [
          Text('${percent.toStringAsFixed(0)}%', style: TextStyle(fontSize: getFontSize(22), fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          const Text('Time in Range'),
        ]),
        // 범례
        const Positioned(
          right: 0,
          top: 0,
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            _LegendDot(color: Colors.orange, label: 'High 17%'),
            _LegendDot(color: Colors.blue, label: 'In Range 75%'),
            _LegendDot(color: Colors.pink, label: 'Low 4%'),
            _LegendDot(color: Colors.red, label: 'Very Low 4%'),
          ]),
        ),
      ]),
    );
  }

  Widget _tirPieCard(bool isDark) {
    final Map<String, double> t = _tir ?? {'veryHigh': 0.17, 'inRange': 0.62, 'low': 0.12, 'veryLow': 0.09};
    final double veryHigh = (t['veryHigh'] ?? 0).clamp(0.0, 1.0);
    final double inRange = (t['inRange'] ?? 0).clamp(0.0, 1.0);
    final double low = (t['low'] ?? 0).clamp(0.0, 1.0);
    final double veryLow = (t['veryLow'] ?? 0).clamp(0.0, 1.0);
    final double total = (veryHigh + inRange + low + veryLow);
    double safe(double v){ return total > 0 ? v/total : 0; }
    final double vh = safe(veryHigh);
    final double ir = safe(inRange);
    final double lo = safe(low);
    final double vl = safe(veryLow);

    return Container(
      padding: getPadding(all: 12),
      decoration: BoxDecoration(
        color: isDark ? ColorConstant.darkTextField : ColorConstant.whiteA700,
        borderRadius: BorderRadius.circular(getHorizontalSize(12)),
        border: Border.all(color: ColorConstant.indigo51, width: 1),
      ),
      child: Row(
        children: [
          SizedBox(
            width: 160,
            height: 160,
            child: PieChart(
              PieChartData(
                sectionsSpace: 2,
                centerSpaceRadius: 36,
                sections: [
                  if (vh > 0) PieChartSectionData(color: Colors.orange, value: vh, title: ''),
                  if (ir > 0) PieChartSectionData(color: Colors.blue, value: ir, title: ''),
                  if (lo > 0) PieChartSectionData(color: Colors.pink, value: lo, title: ''),
                  if (vl > 0) PieChartSectionData(color: Colors.red, value: vl, title: ''),
                ],
              ),
            ),
          ),
          HorizontalSpace(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                _LegendDot(color: Colors.orange, label: 'High'),
                SizedBox(height: 6),
                _LegendDot(color: Colors.blue, label: 'In Range'),
                SizedBox(height: 6),
                _LegendDot(color: Colors.pink, label: 'Low'),
                SizedBox(height: 6),
                _LegendDot(color: Colors.red, label: 'Very Low'),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // --- charts for Trend tab ---
  // removed old summary charts (replaced by new report card)

  // removed

  // removed

}

class _LegendDot extends StatelessWidget {
  const _LegendDot({required this.color, required this.label});
  final Color color;
  final String label;
  @override
  Widget build(BuildContext context) {
    return Row(mainAxisSize: MainAxisSize.min, children: [
      Container(width: 10, height: 10, decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(2))),
      const SizedBox(width: 6),
      Text(label, style: const TextStyle(fontSize: 12)),
    ]);
  }
}

class _ChartLandscapeScreen extends StatelessWidget {
  const _ChartLandscapeScreen({required this.hoursRange});
  final String hoursRange;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Padding(
        padding: const EdgeInsets.only(top: 20),
        child: RotatedBox(
          quarterTurns: 1,
          child: Stack(children: [
          Positioned.fill(
            child: ChartPage(
              embedded: true,
              hoursRange: hoursRange,
              startWide: true,
            ),
          ),
          // 가로→세로 복귀 아이콘(얇은 반투명 배경 유지)
          Positioned(
            right: 12,
            top: 12,
            child: Tooltip(
              message: 'Back to Portrait',
              child: Material(
                color: Colors.transparent,
                child: InkWell(
                  borderRadius: BorderRadius.circular(22),
                  onTap: () => Navigator.of(context).pop(),
                  child: Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.18),
                      borderRadius: BorderRadius.circular(22),
                    ),
                    child: const Icon(Icons.stay_current_portrait, color: Colors.white),
                  ),
                ),
              ),
            ),
          ),
        ]),
        ),
      ),
    );
  }
}


