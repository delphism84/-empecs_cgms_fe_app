import 'package:flutter/material.dart';
// removed unused async import
import 'dart:math' as math;
import 'package:fl_chart/fl_chart.dart';
import 'dart:async';
import 'package:flutter/services.dart';
import 'package:helpcare/core/app_export.dart';
import 'package:helpcare/core/utils/api_client.dart';
import 'package:helpcare/core/utils/settings_service.dart';
import 'package:helpcare/widgets/custom_text_form_field.dart';
import 'package:helpcare/core/utils/focus_bus.dart';
import 'package:helpcare/core/utils/data_sync_bus.dart';

class ChartPage extends StatefulWidget {
  const ChartPage({super.key, this.embedded = false, this.startWide = false, this.initialDay, this.hoursRange = '6h', this.onAddMemo, this.refreshTick});

  final bool embedded;
  final bool startWide;
  final DateTime? initialDay;
  final String hoursRange;
  final VoidCallback? onAddMemo;
  final ValueNotifier<int>? refreshTick;

  @override
  State<ChartPage> createState() => _ChartPageState();
}

class _ChartPageState extends State<ChartPage> {
  static const double _defaultMaxY = 250.0;
  static const double _absoluteMaxY = 450.0;

  DateTime currentDay = DateTime.now();
  List<GlucosePoint> points = [];
  List<GlucoseEvent> events = [];
  String _unit = 'mg/dL';
  double _unitFactor = 1.0; // 1.0 for mg/dL, 1/18.0 for mmol/L

  // interaction state
  int? selectedIndex;
  bool isWideMode = false;

  final ScrollController recordScrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    if (widget.initialDay != null) {
      currentDay = widget.initialDay!;
    }
    isWideMode = widget.startWide;
    _fetchFromServer();
    _loadUnit();
    widget.refreshTick?.addListener(_fetchFromServer);
    GlucoseFocus.focusTime.addListener(_onExternalFocus);
    AppSettingsBus.changed.addListener(_onSettingsChanged);
    _syncSub = DataSyncBus().stream.listen(_onDataSync);
  }

  @override
  void didUpdateWidget(covariant ChartPage oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.refreshTick != widget.refreshTick) {
      oldWidget.refreshTick?.removeListener(_fetchFromServer);
      widget.refreshTick?.addListener(_fetchFromServer);
    }
  }

  @override
  void dispose() {
    GlucoseFocus.focusTime.removeListener(_onExternalFocus);
    AppSettingsBus.changed.removeListener(_onSettingsChanged);
    _syncSub?.cancel();
    super.dispose();
  }

  void _onExternalFocus() {
    final DateTime? t = GlucoseFocus.focusTime.value;
    if (t == null || points.isEmpty) return;
    int best = 0;
    int bestDelta = 1 << 30;
    for (int i = 0; i < points.length; i++) {
      final int d = (points[i].time.millisecondsSinceEpoch - t.millisecondsSinceEpoch).abs();
      if (d < bestDelta) { bestDelta = d; best = i; }
    }
    setState(() { selectedIndex = best; });
    // 스크롤 뷰포트에 보이도록 이동
    final double desiredCenter = best.toDouble();
    final n = math.max(1, points.length - 1);
    windowSizeClamp() {
      int stepMinutes = 30;
      if (points.length >= 2) {
        stepMinutes = (points[1].time.difference(points[0].time).inMinutes.abs()).clamp(1, 240);
      }
      final double pointsPerHour = 60.0 / stepMinutes;
      return (widget.hoursRange == '12h' ? 12.0 : 6.0) * pointsPerHour;
    }
    final double size = windowSizeClamp().clamp(2, n.toDouble());
    final double start = (desiredCenter - size / 2).clamp(0, math.max(0.0, n - size));
    setState(() {
      // _FlGlucoseChartState의 상태에 접근할 수 없으므로 selectedIndex만 반영하고,
      // 최신 데이터 로드로 뷰포트는 자연스럽게 최신 구간으로 유지되도록 둔다.
      // 필요 시 내부 상태 공유로 확장 가능.
    });
  }

  void _onSettingsChanged() {
    // 단위 변경 등 설정이 바뀌면 서버에서 재로드하고 y축/데이터 갱신
    _loadUnit();
    _fetchFromServer();
    setState(() {});
  }

  StreamSubscription<DataSyncEvent>? _syncSub;
  void _onDataSync(DataSyncEvent ev) {
    if (!mounted) return;
    if (ev.kind == DataSyncKind.glucosePoint) {
      // 새 포인트가 왔어도 자동 뷰포트 이동/선택 갱신은 하지 않음
      _fetchFromServer();
    } else if (ev.kind == DataSyncKind.eventItem) {
      _fetchFromServer();
      // 자동 포커스/스크롤 이동 금지
    }
  }

  Future<void> _fetchFromServer() async {
    try {
      final ds = DataService();
      final now = DateTime.now();
      final from = now.subtract(const Duration(days: 7));
      // to 범위를 now + 1시간으로 확장해 우측 여유 구간을 서버 데이터에서도 포함
      final DateTime to = now.add(const Duration(hours: 1));
      final ev = await ds.fetchEvents(from: from, to: to, limit: 1000);
      final gp = await ds.fetchGlucose(from: from, to: to, limit: 2000);
      if (!mounted) return;
      setState(() {
        if (gp.isNotEmpty) {
          points = gp
              .map((e) => GlucosePoint(
                    time: DateTime.parse(e['time'] as String).toLocal(),
                    value: (e['value'] as num).toDouble(),
                  ))
              .toList()
            ..sort((a, b) => a.time.compareTo(b.time));
        }
        if (ev.isNotEmpty) {
          events = ev.map((e) {
            final String t = (e['type'] as String).toString();
            final EventType ty = {
              'bloodGlucose': EventType.bloodGlucose,
              'exercise': EventType.exercise,
              'insulin': EventType.insulin,
              'memo': EventType.memo,
              'meal': EventType.meal,
              'medication': EventType.medication,
            }[t] ?? EventType.memo;
            return GlucoseEvent(
              id: (e['_id'] as String?) ?? '',
              type: ty,
              time: DateTime.parse(e['time'] as String).toLocal(),
              memo: e['memo'] as String?,
            );
          }).toList()
            ..sort((a, b) => a.time.compareTo(b.time));
        }
      });
    } catch (_) {
      // network 실패 시 목업 유지
    }
  }

  Future<void> _loadUnit() async {
    try {
      final SettingsService ss = SettingsService();
      final Map<String, dynamic> app = await ss.getAppSetting();
      final String u = (app['unit'] as String?) ?? 'mg/dL';
      setState(() {
        _unit = (u == 'mmol/L') ? 'mmol/L' : 'mg/dL';
        _unitFactor = (_unit == 'mmol/L') ? (1.0 / 18.0) : 1.0;
      });
    } catch (_) {}
  }

  // 날짜 단위 이동 제거 (스와이프로 시간축 이동)

  double _averageGlucose() {
    if (points.isEmpty) return 0;
    final double sum = points.map((p) => p.value).reduce((a, b) => a + b);
    return sum / points.length;
  }

  double _stdDevGlucose() {
    if (points.length < 2) return 0;
    final double avg = _averageGlucose();
    final double varSum = points.map((p) => math.pow(p.value - avg, 2).toDouble()).reduce((a, b) => a + b);
    final double variance = varSum / (points.length - 1);
    return math.sqrt(variance);
  }

  // trend calc moved to tooltip; no separate trend indicator for fl_chart version

  @override
  Widget build(BuildContext context) {
    // 날짜 라벨/요일 미사용 (시간축 연속 스와이프)
    final double avg = _averageGlucose();
    final double std = _stdDevGlucose();
    final bool isDark = Theme.of(context).brightness == Brightness.dark;
    // theme

    final double dynamicMaxY = _resolveMaxY();
    return Scaffold(
      backgroundColor: widget.embedded ? Colors.transparent : Colors.white,
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      floatingActionButton: null,
      body: Column(
          children: [
            Expanded(
              child: LayoutBuilder(
                builder: (context, constraints) {
                  return Column(
                  children: [
                      // graph area (rounded box + light grey border 1px)
                      Expanded(flex: 5,
                        child: Container(
                          margin: isWideMode ? EdgeInsets.zero : const EdgeInsets.fromLTRB(0, 20, 0, 12),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          clipBehavior: Clip.antiAlias,
                          child: Stack(
                            children: [
                              Positioned.fill(
                                child: _FlGlucoseChart(
                                  points: points,
                                  events: events,
                                  maxY: dynamicMaxY * _unitFactor,
                                  isWideMode: isWideMode,
                                  average: avg,
                                  stddev: std,
                                  targetY: 140,
                                  initialHours: _hoursFromRange(widget.hoursRange),
                                  displayUnit: _unit,
                                  unitFactor: _unitFactor,
                                  onSelectIndex: (i) {
                                    setState(() => selectedIndex = i);
                                    // 선택 지점과 가장 가까운 이벤트로 리스트 스크롤 연동
                                    if (!isWideMode && events.isNotEmpty) {
                                      final DateTime pt = points[i].time;
                                      int best = 0;
                                      int bestDelta = 1 << 30;
                                      for (int k = 0; k < events.length; k++) {
                                        final int d = (events[k].time.millisecondsSinceEpoch - pt.millisecondsSinceEpoch).abs();
                                        if (d < bestDelta) {
                                          bestDelta = d;
                                          best = k;
                                        }
                                      }
                                      WidgetsBinding.instance.addPostFrameCallback((_) {
                                        recordScrollController.animateTo(
                                          best * 72.0,
                                          duration: const Duration(milliseconds: 300),
                                          curve: Curves.easeOut,
                                        );
                                      });
                                    }
                                  },
                                  onEventTap: (eventId) {
                                    final int idx = events.indexWhere((e) => e.id == eventId);
                                    if (idx != -1) {
                                      WidgetsBinding.instance.addPostFrameCallback((_) {
                                        recordScrollController.animateTo(
                                          idx * 72.0,
                                          duration: const Duration(milliseconds: 300),
                                          curve: Curves.easeOut,
                                        );
                                      });
                                    }
                                  },
                                ),
                              ),
                              // removed chart overlay maximize; now in top bar
                            // wide 평균 표시는 내부 차트에서 뷰포트 기준으로 렌더링
                  ],
                ),
                        ),
                      ),
                      if (!isWideMode) const Divider(height: 1),
                      // records area (하단까지 확장) + 내부 오버레이 FAB
                      if (!isWideMode)
                        Expanded(flex: 3,
                          child: Stack(
                            children: [
                              ListView.separated(
                                controller: recordScrollController, 
                                itemBuilder: (context, index) {
                                  final GlucoseEvent e = events[index];
                                  return ListTile(
                                    visualDensity: const VisualDensity(vertical: -2),
                                    minLeadingWidth: 0,
                                    horizontalTitleGap: 8,
                                    dense: true,
                                    leading: _EventBadge(type: e.type, size: 28),
                                    title: Text(
                                      '${_eventLabel(e.type)} · ${_formatDateTime(e.time)}',
                                      style: TextStyle(
                                        color: isDark ? Colors.white : Colors.black,
                                        fontSize: getFontSize(13),
                                        fontFamily: 'Gilroy-Medium',
                                        fontWeight: FontWeight.w400,
                                      ),
                                    ),
                                    subtitle: Text(
                                      e.memo ?? '',
                                      style: TextStyle(
                                        color: isDark ? Colors.white70 : ColorConstant.bluegray400,
                                        fontSize: getFontSize(11),
                                        fontFamily: 'Gilroy-Medium',
                                        fontWeight: FontWeight.w400,
                                      ),
                                    ),
                                    onTap: () async {
                                      final result = await Navigator.of(context).push(
                                        MaterialPageRoute(builder: (_) => EventViewPage(initial: e)),
                                      );
                                      if (result is String) {
                                        if (result == 'deleted') {
                                          final ds = DataService();
                                          final ok = await ds.deleteEvent(e.id);
                                          if (!context.mounted) return;
                                          ScaffoldMessenger.of(context).showSnackBar(
                                            SnackBar(content: Text(ok ? 'Event deleted' : 'Failed to delete')),
                                          );
                                          if (ok) setState(() {});
                                        }
                                      }
                                    },
                                  );
                                },
                                separatorBuilder: (context, _) => const Divider(height: 1),
                                itemCount: events.length,
                              ),
                              if (widget.onAddMemo != null)
                                Positioned(
                                  right: 16,
                                  bottom: 16,
                                  child: FloatingActionButton.small(
                                    onPressed: widget.onAddMemo,
                                    child: const Icon(Icons.sticky_note_2_outlined),
                                  ),
                                ),
                            ],
                          ),
                        ),
                    ],
                  );
                },
              ),
            ),
          ],
        ),
    );
  }

  double _resolveMaxY() {
    if (points.isEmpty) return _defaultMaxY;
    double maxV = 0;
    for (final p in points) {
      if (p.value > maxV) maxV = p.value;
    }
    // 기본 250, 초과 시 여유 헤드룸 10% 추가, 단 450 상한
    final double target = maxV <= _defaultMaxY
        ? _defaultMaxY
        : (maxV * 1.1).clamp(_defaultMaxY, _absoluteMaxY);
    return target;
  }

  static IconData _iconForEvent(EventType t) {
    switch (_categoryForType(t)) {
      case EventCategory.bloodGlucose:
        // 혈액방울 아이콘으로 변경
        return Icons.water_drop;
      case EventCategory.insulin:
        return Icons.vaccines;
      case EventCategory.medication:
        return Icons.medication;
      case EventCategory.exercise:
        return Icons.directions_run;
      case EventCategory.meal:
        return Icons.restaurant;
      case EventCategory.memo:
        return Icons.sticky_note_2_outlined;
    }
  }

  static Color _colorForEvent(EventType t) {
    // Memo(녹색)로 통일
    return Colors.green;
  }

  static String _eventLabel(EventType t) {
    // 라벨은 요구된 6개 명칭으로 고정
    switch (_categoryForType(t)) {
      case EventCategory.bloodGlucose:
        return 'Blood glucose';
      case EventCategory.insulin:
        return 'Insulin';
      case EventCategory.medication:
        return 'Medication';
      case EventCategory.exercise:
        return 'Exercise';
      case EventCategory.meal:
        return 'Meal';
      case EventCategory.memo:
        return 'Memo';
    }
  }

  // replaced by _formatDateTime

  static String _formatDateTime(DateTime d) {
    final String yyyy = d.year.toString().padLeft(4, '0');
    final String mm1 = d.month.toString().padLeft(2, '0');
    final String dd = d.day.toString().padLeft(2, '0');
    final String hh = d.hour.toString().padLeft(2, '0');
    final String mm = d.minute.toString().padLeft(2, '0');
    return '$yyyy-$mm1-$dd $hh:$mm';
  }

  double _hoursFromRange(String r) {
    if (r.endsWith('h')) {
      final String n = r.substring(0, r.length - 1);
      final double? v = double.tryParse(n);
      if (v != null && v > 0) return v;
    }
    return 12; // default 12h
  }

}

class _InteractiveChart extends StatefulWidget {
  const _InteractiveChart({
    required this.points,
    required this.events,
    required this.maxY,
    required this.isWideMode,
    required this.scaleX,
    required this.translateX,
    required this.onInteraction,
    required this.onSelectIndex,
    required this.onEventTap,
    required this.hoursRange,
  });

  final List<GlucosePoint> points;
  final List<GlucoseEvent> events;
  final double maxY;
  final bool isWideMode;
  final double scaleX;
  final double translateX;
  final void Function(double scaleX, double translateX) onInteraction;
  final void Function(int index) onSelectIndex;
  final void Function(String eventId) onEventTap;
  final String hoursRange;

  @override
  State<_InteractiveChart> createState() => _InteractiveChartState();
}

class _InteractiveChartState extends State<_InteractiveChart> {
  // view transform state (managed by parent via onInteraction)
  double startScaleX = 1.0;
  double startTranslateX = 0.0;
  // removed pan tracking in touch-disabled mode

  // inspect mode
  bool inspectMode = false;
  int? selectedIndex;

  // hit tolerances (unused while touch disabled)
  // static const double yHitTolerancePx = 8.0;
  // static const double xHitTolerancePx = 12.0;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final double width = constraints.maxWidth;
        final double height = constraints.maxHeight;
        // 터치 비활성화 고정

        // touch disabled: always paint chart only
        return CustomPaint(
          size: Size(width, height),
          painter: GlucoseChartPainter(
            points: widget.points,
            maxY: widget.maxY,
            scaleX: widget.scaleX,
            translateX: widget.translateX,
            selectedIndex: selectedIndex,
            showXLabelsFor: widget.hoursRange,
          ),
        );
      },
    );
  }

  // int _hitTestX(double dx, double width) { return 0; }

  // double? _yForIndex(int idx, double height) => null;

  // double _xForIndex(int i, double width) => width / 2;

  // Offset _posForIndex(int idx, double width, double height) => Offset.zero;

  // double _xForTime(DateTime t, double width) => width / 2;
}

class GlucoseChartPainter extends CustomPainter {
  GlucoseChartPainter({
    required this.points,
    required this.maxY,
    required this.scaleX,
    required this.translateX,
    this.selectedIndex,
    required this.showXLabelsFor,
  });

  final List<GlucosePoint> points;
  final double maxY;
  final double scaleX;
  final double translateX;
  final int? selectedIndex;
  final String showXLabelsFor;

  @override
  void paint(Canvas canvas, Size size) {
    final Paint gridPaint = Paint()
      ..color = const Color(0xFFE0E0E0)
      ..strokeWidth = 1;

    // grid horizontal lines (5 levels)
    for (int i = 0; i <= 5; i++) {
      final double y = size.height * (i / 5);
      canvas.drawLine(Offset(0, y), Offset(size.width, y), gridPaint);
    }

    if (points.isEmpty) return;

    final Path path = Path();
    final Paint linePaint = Paint()
      ..color = Colors.blueAccent
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;

    for (int i = 0; i < points.length; i++) {
      final double x = _xForIndex(i, size.width);
      final double y = size.height - (points[i].value / maxY * size.height);
      if (i == 0) {
        path.moveTo(x, y);
      } else {
        path.lineTo(x, y);
      }
    }
    canvas.drawPath(path, linePaint);

    // draw point only when selected (hide all dots by default)
    if (selectedIndex != null && selectedIndex! >= 0 && selectedIndex! < points.length) {
      final Paint dot = Paint()..color = Colors.blueAccent;
      final double x = _xForIndex(selectedIndex!, size.width);
      final double y = size.height - (points[selectedIndex!].value / maxY * size.height);
      canvas.drawCircle(Offset(x, y), 3, dot);
    }

    // selection indicator
    if (selectedIndex != null && selectedIndex! >= 0 && selectedIndex! < points.length) {
      final double sx = _xForIndex(selectedIndex!, size.width);
      final double sy = size.height - (points[selectedIndex!].value / maxY * size.height);
      final Paint sel = Paint()..color = Colors.redAccent;
      canvas.drawCircle(Offset(sx, sy), 4.5, sel);
      // vertical line
      final Paint v = Paint()
        ..color = Colors.black26
        ..strokeWidth = 1;
      canvas.drawLine(Offset(sx, 0), Offset(sx, size.height), v);
    }

    // x-axis labels with non-overlap based on hoursRange
    final TextPainter tp = TextPainter(textAlign: TextAlign.center, textDirection: TextDirection.ltr);
    final int step = _xLabelStep(showXLabelsFor);
    for (int i = 0; i < points.length; i += step) {
      final double x = _xForIndex(i, size.width);
      final DateTime t = points[i].time;
      final String label = _formatHour(t);
      tp.text = TextSpan(text: label, style: const TextStyle(fontSize: 10, color: Colors.black54));
      tp.layout();
      final double tx = (x - tp.width / 2).clamp(0, math.max(0.0, size.width - tp.width));
      tp.paint(canvas, Offset(tx, size.height - tp.height));
    }
  }

  double _xForIndex(int i, double width) {
    if (points.length == 1) return width / 2 + translateX;
    final double x = (i / (points.length - 1)) * width;
    final double transformed = ((x - width / 2) * scaleX) + width / 2 + translateX;
    return transformed;
  }

  @override
  bool shouldRepaint(covariant GlucoseChartPainter oldDelegate) {
    return oldDelegate.points != points ||
        oldDelegate.maxY != maxY ||
        oldDelegate.scaleX != scaleX ||
        oldDelegate.translateX != translateX ||
        oldDelegate.selectedIndex != selectedIndex ||
        oldDelegate.showXLabelsFor != showXLabelsFor;
  }

  int _xLabelStep(String r) {
    // 시간 범위에 따라 레이블 샘플링 조절 (겹침 방지)
    if (r == '6h') return 4;   // 3시간당 1개
    if (r == '12h') return 8;  // 4시간당 1개
    if (r == '24h') return 12; // 6시간당 1개
    return 8; // default
  }

  String _formatHour(DateTime d) {
    final String hh = d.hour.toString().padLeft(2, '0');
    return '$hh:00';
  }
}

class GlucosePoint {
  GlucosePoint({required this.time, required this.value});
  final DateTime time;
  final double value;
}

// 6개 카테고리에 맞춘 간소화된 이벤트 타입
enum EventType { bloodGlucose, insulin, medication, exercise, meal, memo }

class GlucoseEvent {
  GlucoseEvent({required this.id, required this.type, required this.time, this.memo});
  final String id;
  final EventType type;
  final DateTime time;
  final String? memo;
}

// Canonical categories to unify icon set across features
enum EventCategory { bloodGlucose, insulin, medication, exercise, meal, memo }

EventCategory _categoryForType(EventType t) {
  switch (t) {
    case EventType.bloodGlucose:
      return EventCategory.bloodGlucose;
    case EventType.insulin:
      return EventCategory.insulin;
    case EventType.medication:
      return EventCategory.medication;
    case EventType.exercise:
      return EventCategory.exercise;
    case EventType.meal:
      return EventCategory.meal;
    case EventType.memo:
      return EventCategory.memo;
  }
}

class _EventBadge extends StatelessWidget {
  const _EventBadge({required this.type, this.size = 32});
  final EventType type;
  final double size;

  @override
  Widget build(BuildContext context) {
    final _EventAsset asset = _eventAsset(type);
    final Color ring = Colors.white;
    final Color bg = asset.backgroundColor ?? _ChartPageState._colorForEvent(type);
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: bg,
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.12), blurRadius: 4, offset: const Offset(0, 2))],
      ),
      child: Stack(children: [
        // white ring
        Positioned.fill(
          child: Padding(
            padding: EdgeInsets.all(size * 0.06),
            child: DecoratedBox(
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: ring, width: size * 0.10),
              ),
            ),
          ),
        ),
        // center icon (asset or fallback material icon)
        Center(
          child: SizedBox(
            width: size * 0.55,
            height: size * 0.55,
            child: asset.widget ?? Icon(
              _ChartPageState._iconForEvent(type),
              size: size * 0.55,
              color: Colors.white,
            ),
          ),
        ),
      ]),
    );
  }
}

class _EventAsset {
  const _EventAsset({this.widget, this.backgroundColor});
  final Widget? widget;
  final Color? backgroundColor;
}

_EventAsset _eventAsset(EventType type) {
  // 에셋 파일명을 필요시 여기에 매핑한다. 없으면 null로 두어 머티리얼 아이콘을 폴백.
  switch (type) {
    case EventType.meal:
      return const _EventAsset(widget: null, backgroundColor: Color(0xFFFFB74D)); // meal – orange
    case EventType.medication:
      return const _EventAsset(widget: null, backgroundColor: Color(0xFF26A69A)); // medication – teal
    case EventType.exercise:
      return const _EventAsset(widget: null, backgroundColor: Color(0xFF5C6BC0)); // exercise – indigo
    case EventType.insulin:
      return const _EventAsset(widget: null, backgroundColor: Color(0xFFAB47BC)); // insulin – purple
    case EventType.bloodGlucose:
      return const _EventAsset(widget: null, backgroundColor: Color(0xFFE57373)); // blood glucose – red
    case EventType.memo:
      return const _EventAsset(widget: null, backgroundColor: Color(0xFF2ECC71)); // memo – green
  }
}

enum TrendArrow { up, down, steady }

class EventViewPage extends StatelessWidget {
  const EventViewPage({super.key, required this.initial});

  final GlucoseEvent initial;

  @override
  Widget build(BuildContext context) {
    final bool isDark = Theme.of(context).brightness == Brightness.dark;
    final TextEditingController memo = TextEditingController(text: initial.memo ?? '');
    return Scaffold(
      appBar: AppBar(title: const Text('Event Detail')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // 헤더 카드: 아이콘 + 타입 + 시간
            Card(
              color: Colors.white,
              elevation: 0,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
                side: BorderSide(color: ColorConstant.green500, width: 1),
              ),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    _EventBadge(type: initial.type, size: 44),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            _ChartPageState._eventLabel(initial.type),
                            style: TextStyle(fontSize: getFontSize(16), fontWeight: FontWeight.w700),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            _ChartPageState._formatDateTime(initial.time),
                            style: const TextStyle(color: Colors.black54),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            // 메모 카드: 로그인 폼과 동일한 입력 필드 톤 사용
            Card(
              color: Colors.white,
              elevation: 0,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
                side: BorderSide(color: ColorConstant.green500, width: 1),
              ),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Memo', style: TextStyle(fontSize: getFontSize(14), fontWeight: FontWeight.w600)),
                    const SizedBox(height: 8),
                    CustomTextFormField(
                      isDark: isDark,
                      width: double.infinity,
                      controller: memo,
                      variant: TextFormFieldVariant.OutlineDeeppurple101,
                      padding: TextFormFieldPadding.PaddingT19,
                      hintText: 'Enter memo...',
                      textInputAction: TextInputAction.newline,
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),
            // 액션 버튼: 로그인 화면의 버튼 스타일 사용
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => Navigator.of(context).pop('deleted'),
                    icon: const Icon(Icons.delete_outline),
                    label: const Text('Delete'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () => Navigator.of(context).pop('saved:${memo.text}'),
                    icon: const Icon(Icons.save),
                    label: const Text('Save'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _FlGlucoseChart extends StatefulWidget {
  const _FlGlucoseChart({
    required this.points,
    required this.events,
    required this.maxY,
    required this.isWideMode,
    required this.average,
    required this.stddev,
    required this.targetY,
    required this.onSelectIndex,
    required this.onEventTap,
    this.initialHours = 12,
    required this.displayUnit,
    required this.unitFactor,
  });

  final List<GlucosePoint> points;
  final List<GlucoseEvent> events;
  final double maxY;
  final bool isWideMode;
  final double average;
  final double stddev;
  final double targetY;
  final void Function(int index) onSelectIndex;
  final void Function(String eventId) onEventTap;
  final double initialHours;
  final String displayUnit;
  final double unitFactor;

  @override
  State<_FlGlucoseChart> createState() => _FlGlucoseChartState();
}

class _FlGlucoseChartState extends State<_FlGlucoseChart> {
  int? touchedIndex;
  double? _oneFingerLastDx;
  // time-based viewport in milliseconds
  double windowStart = 0; // start time (ms since epoch)
  double windowSize = 0;  // duration (ms)
  double startWindowStart = 0;
  double startWindowSize = 5;
  Offset? lastFocal;
  // removed bottom popup feature; using top label at crosshair instead
  int _activePointers = 0; // 1-finger: data touch, 2-finger: pan/zoom
  final Map<int, Offset> _pointerPositions = <int, Offset>{};
  bool _twoFingerActive = false;
  Offset? _twoStartFocal;
  double _twoStartSpan = 1.0;
  double _panelWidth = 1.0;
  int _snapRightEndMs(DateTime now) {
    // 현재시간을 3시간 배수 경계(예: 03:00, 06:00, 09:00 ...)의 직후로 스냅
    final DateTime local = now;
    final int hour = local.hour;
    final int snappedHour = ((hour / 3).ceil()) * 3; // 다음 3의 배수 시각
    final DateTime snapped = DateTime(local.year, local.month, local.day, snappedHour).add(const Duration(minutes: 0));
    return snapped.millisecondsSinceEpoch;
  }

  double _rightEndMs() {
    final double nowPad = DateTime.now().add(const Duration(hours: 1)).millisecondsSinceEpoch.toDouble();
    final double last = widget.points.isNotEmpty ? widget.points.last.time.millisecondsSinceEpoch.toDouble() : nowPad;
    return math.min(last, nowPad);
  }

  void _clampWindow() {
    final double rightEnd = _rightEndMs();
    final double minStart = widget.points.isNotEmpty
        ? widget.points.first.time.millisecondsSinceEpoch.toDouble()
        : (rightEnd - 30 * 24 * 3600000.0);
    if (windowStart < minStart) windowStart = minStart;
    if (windowStart + windowSize > rightEnd) windowStart = rightEnd - windowSize;
  }

  double _tickIntervalMs() {
    // 범위 스냅: 3/6/12/24h만 허용
    final double currentHours = (windowSize / 3600000.0).clamp(0.5, 240.0);
    final List<double> allowed = <double>[3, 6, 12, 24];
    double snap = allowed.first;
    double bestDelta = (currentHours - snap).abs();
    for (final double h in allowed) {
      final double d = (currentHours - h).abs();
      if (d < bestDelta) { snap = h; bestDelta = d; }
    }
    // 간격 매핑: 3->1h, 6->1h, 12->3h, 24->3h
    final double tickHours = (snap <= 6.0) ? 1.0 : 3.0;
    return (tickHours * 3600000.0);
  }

  String _formatHoursLabel() {
    final double hRaw = (windowSize / 3600000.0);
    final double h = hRaw.isFinite ? hRaw.clamp(0.1, 240.0) : 3.0;
    // 라벨 스냅: 3/6/12/24
    final List<double> allowed = <double>[3, 6, 12, 24];
    double best = allowed.first;
    double bestDelta = (h - best).abs();
    for (final double a in allowed) {
      final double d = (h - a).abs();
      if (d < bestDelta) { best = a; bestDelta = d; }
    }
    final double snapped = best;
    return '${snapped.toStringAsFixed(0)} Hours';
  }
  double _pointsPerHour() {
    int stepMinutes = 30;
    if (widget.points.length >= 2) {
      stepMinutes = (widget.points[1].time.difference(widget.points[0].time).inMinutes.abs()).clamp(1, 240);
    }
    return 60.0 / stepMinutes;
  }

  double _rightPadPoints() {
    final double pph = _pointsPerHour();
    final double currentHours = (windowSize / pph).clamp(0.5, 240.0);
    final List<double> allowed = <double>[3, 6, 12, 24];
    double best = allowed.first;
    double bestDelta = (currentHours - best).abs();
    for (final double h in allowed) {
      final double d = (currentHours - h).abs();
      if (d < bestDelta) { best = h; bestDelta = d; }
    }
    final double tickHours = best <= 3.0 ? 0.5 : (best <= 6.0 ? 1.0 : (best <= 12.0 ? 2.0 : 4.0));
    return tickHours * pph;
  }

  // removed: _effectiveWindowSize (ms 기반으로 일원화)
  // focus/scrub mode via long-press
  // scrub mode, haptic vars removed (unused)
  // removed unused haptic buckets

  @override
  void initState() {
    super.initState();
    // 초기 뷰포트: 지정 시간(기본 12시간)을 ms로 사용 + 우측 끝은 현재시간을 3시간 단위 경계로 스냅
    final int desiredMs = (widget.initialHours * 3600000).round();
    final int endMs = _snapRightEndMs(DateTime.now());
    final int startMs = endMs - desiredMs;
    windowSize = desiredMs.toDouble();
    windowStart = startMs.toDouble();
    // removed: external date callback
  }

  @override
  void didUpdateWidget(covariant _FlGlucoseChart oldWidget) {
    super.didUpdateWidget(oldWidget);
    // 포인트 수 변동으로는 뷰포트를 리셋하지 않음 (자동이동 방지)
    if (oldWidget.initialHours != widget.initialHours) {
      // 우측 끝을 유지한 채(windowStart+windowSize) 크기만 변경
      final double rightEnd = windowStart + windowSize;
      final int desiredMs = (widget.initialHours * 3600000).round();
      windowSize = desiredMs.toDouble();
      windowStart = (rightEnd - windowSize);
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    final Color primary = Theme.of(context).colorScheme.primary;
    final List<FlSpot> spots = [
      for (int i = 0; i < widget.points.length; i++)
        FlSpot(widget.points[i].time.millisecondsSinceEpoch.toDouble(), widget.points[i].value)
    ];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
      child: Stack(
          children: [
            // glow when two-finger gesture is active
            if (_twoFingerActive)
              Positioned.fill(
                child: IgnorePointer(
                  child: DecoratedBox(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Colors.white.withOpacity(0.7), width: 1.5),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.white.withOpacity(0.12),
                          blurRadius: 6,
                          spreadRadius: 0,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            Positioned(
              left: 0,
              right: 0,
              top: 16, // leave space for top date strip
              bottom: 0,
              child: LineChart(
        LineChartData(
          // plot/axis insets for consistent overlay alignment
          // keep small left gap to reduce Y-axis to chart spacing
          minX: windowStart,
          maxX: windowStart + windowSize,
          minY: 0,
          maxY: widget.maxY,
          clipData: const FlClipData.all(),
          borderData: FlBorderData(show: false),
          gridData: FlGridData(show: true, drawVerticalLine: false, horizontalInterval: 50 * widget.unitFactor),
                rangeAnnotations: RangeAnnotations(
                  horizontalRangeAnnotations: [
                    // Low 영역 (트렌드 파이: Pink) 50% 투명도
                    HorizontalRangeAnnotation(
                      y1: 0,
                      y2: 70 * widget.unitFactor,
                      color: Colors.pink.withOpacity(0.2),
                    ),
                    // In Range 영역 (트렌드 파이: Blue) 50% 투명도
                    HorizontalRangeAnnotation(
                      y1: 70 * widget.unitFactor,
                      y2: 180 * widget.unitFactor,
                      color: Colors.blue.withOpacity(0.2),
                    ),
                    // High 영역 (트렌드 파이: Orange) 50% 투명도
                    HorizontalRangeAnnotation(
                      y1: 180 * widget.unitFactor,
                      y2: widget.maxY,
                      color: Colors.orange.withOpacity(0.2),
                    ),
                  ],
                ),
                extraLinesData: ExtraLinesData(
                  horizontalLines: const [], // 라인 제거, 색상 블럭만 사용
                  verticalLines: [
                    for (int i = 0; i < widget.events.length; i++)
                      VerticalLine(
                        x: widget.events[i].time.millisecondsSinceEpoch.toDouble(),
                        color: _ChartPageState._colorForEvent(widget.events[i].type).withValues(alpha: 0.4),
                        strokeWidth: 1,
                        dashArray: [4, 3],
                        label: VerticalLineLabel(show: false),
                      ),
                  ],
                ),
          titlesData: FlTitlesData(
            leftTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                reservedSize: 36,
                interval: 50 * widget.unitFactor,
                getTitlesWidget: (value, meta) {
                  final String txt = (widget.unitFactor < 0.99)
                      ? value.toStringAsFixed(1)
                      : value.toStringAsFixed(0);
                  return SideTitleWidget(
                    meta: meta,
                    space: 6,
                    child: Text(txt, style: const TextStyle(fontSize: 10, color: Colors.black54)),
                  );
                },
              ),
            ),
            bottomTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                reservedSize: 22,
                interval: _tickIntervalMs(),
                getTitlesWidget: (value, meta) {
                  if (widget.points.isEmpty) return const SizedBox.shrink();
                  final DateTime t = DateTime.fromMillisecondsSinceEpoch(value.round());
                  final String hh = t.hour.toString().padLeft(2, '0');
                  final String mm = t.minute.toString().padLeft(2, '0');
                  final String label = (mm == '00' || mm == '30') ? '$hh:$mm' : '$hh:00';
                  return SideTitleWidget(
                    meta: meta,
                    space: 6,
                    child: Text(label, style: const TextStyle(fontSize: 10, color: Colors.black54)),
                  );
                },
              ),
            ),
            rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            topTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                reservedSize: 28,
                getTitlesWidget: (value, meta) {
                  if (meta.axisPosition == 0) {
                    return Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 18, bottom: 4),
                          child: Text(widget.displayUnit, style: const TextStyle(fontSize: 11, color: Colors.black87, fontWeight: FontWeight.w600)),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(right: 8, bottom: 4),
                          child: DecoratedBox(
                            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10), boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 4, offset: Offset(0, 1))]),
                            child: Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                              child: Text(_formatHoursLabel(), style: const TextStyle(fontSize: 11, color: Colors.black87, fontWeight: FontWeight.w600)),
                            ),
                          ),
                        ),
                      ],
                    );
                  }
                  return const SizedBox.shrink();
                },
              ),
            ),
          ),
          lineTouchData: const LineTouchData(
            enabled: false,
            handleBuiltInTouches: false,
          ),
          lineBarsData: [
            LineChartBarData(
              isCurved: true,
              barWidth: 2,
              // 색상은 y값(목표 범위)에 따라 동적 지정
              color: null,
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  // 상단값(고혈당) 기준 색상 → 중간(primary) → 저혈당
                  Colors.orange,
                  primary,
                  Colors.red,
                ],
                stops: const [0.0, 0.5, 1.0],
              ),
              dotData: FlDotData(
                show: touchedIndex != null,
                getDotPainter: (s, p, b, i) {
                  if (touchedIndex == null || i != touchedIndex) {
                    return FlDotCirclePainter(radius: 0, color: Colors.transparent);
                  }
                  final double v = widget.points[i].value;
                  final Color dotColor = v < 70
                      ? Colors.red
                      : (v > 180 ? Colors.orange : primary);
                  return FlDotCirclePainter(
                    radius: 4.5,
                    color: dotColor,
                    strokeWidth: 2,
                    strokeColor: Colors.white,
                  );
                },
              ),
              spots: [
                for (int i = 0; i < spots.length; i++)
                  FlSpot(spots[i].x, spots[i].y * widget.unitFactor),
              ],
              belowBarData: BarAreaData(show: false),
            ),
          ],
          // view port & animation (tooltip indicators omitted for compatibility)
              ),
            ),
        // animation disabled for compatibility
      ),
            // top date stripe (16px): show day boxes synced to viewport (align leftInset=0)
      // y-axis labels moved to fl_chart leftTitles (50-unit interval)
      Positioned(
        top: 0,
        left: 0,
        right: 0,
        height: 16,
        child: IgnorePointer(
          child: LayoutBuilder(
            builder: (context, cs) {
              if (widget.points.isEmpty) return const SizedBox.shrink();
              final double plotWidth = cs.maxWidth;
              final DateTime startTime = _timeForIndex(windowStart);
              final DateTime endTime = _timeForIndex(windowStart + windowSize);
              final DateTime centerTime = _timeForIndex(windowStart + windowSize / 2);
              final List<_DaySeg> segs = <_DaySeg>[];
              DateTime segStart = startTime;
              while (segStart.isBefore(endTime)) {
                final DateTime nextMidnight = DateTime(segStart.year, segStart.month, segStart.day + 1);
                final DateTime segEnd = nextMidnight.isBefore(endTime) ? nextMidnight : endTime;
                segs.add(_DaySeg(segStart, segEnd));
                segStart = segEnd;
              }
              List<Widget> children = <Widget>[];
              for (final _DaySeg s in segs) {
                final int startMs = startTime.millisecondsSinceEpoch;
                final int endMs = endTime.millisecondsSinceEpoch;
                final int segStartMs = s.start.millisecondsSinceEpoch;
                final int segEndMs = s.end.millisecondsSinceEpoch;
                final double total = math.max(1.0, (endMs - startMs).toDouble());
                final double rxStart = ((segStartMs - startMs) / total).clamp(0.0, 1.0);
                final double rxEnd = ((segEndMs - startMs) / total).clamp(0.0, 1.0);
                final double left = rxStart * plotWidth;
                final double width = (rxEnd - rxStart) * plotWidth;
                if (width <= 0.5) continue;
                final bool isCenter = !centerTime.isBefore(s.start) && centerTime.isBefore(s.end);
                final String label = '${s.start.month}/${s.start.day}';
                children.add(Positioned(
                  left: left + 4,
                  width: width - 8,
                  top: 0,
                  bottom: 0,
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      label,
                      style: TextStyle(
                        fontSize: isCenter ? 16 : 10,
                        fontWeight: isCenter ? FontWeight.w700 : FontWeight.w500,
                        color: Colors.black87,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.clip,
                    ),
                  ),
                ));
              }
              return Stack(children: children);
            },
          ),
        ),
      ),
            // removed: internal top-center date (will be rendered by parent just above chart bounds)
            // viewport-average (wide mode only) -> move under first event icon area as white card
            if (widget.isWideMode)
              Positioned(
                top: 56, // back 버튼 하단으로 내리고 +20px 상단 패딩 효과
                left: 20, // add 20px left padding in wide mode
                child: Material(
                  color: Colors.white,
                  elevation: 0,
                  borderRadius: BorderRadius.circular(10),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.show_chart, size: 16, color: Colors.black54),
                        const SizedBox(width: 6),
                        Text('Avg ${_viewportAverage().toStringAsFixed(0)}', style: const TextStyle(fontSize: 12, color: Colors.black87)),
                      ],
                    ),
                  ),
                ),
              ),
            // gesture overlay: strictly 2-finger for pan/zoom
            Positioned.fill(
              child: LayoutBuilder(builder: (context, c) {
                final double width = c.maxWidth;
                return Listener(
                behavior: HitTestBehavior.translucent,
                onPointerDown: (e) {
                  _pointerPositions[e.pointer] = e.position;
                  _activePointers = _pointerPositions.length;
                  if (_activePointers == 2) {
                    // start two-finger gesture
                    final List<Offset> pts = _pointerPositions.values.toList();
                    _twoStartFocal = (pts[0] + pts[1]) / 2;
                    _twoStartSpan = (pts[0] - pts[1]).distance;
                    startWindowStart = windowStart;
                    startWindowSize = windowSize;
                    _twoFingerActive = true;
                  }
                  setState(() {});
                },
                  onPointerMove: (e) {
                  _pointerPositions[e.pointer] = e.position;
                  if (_pointerPositions.length >= 2 && _twoFingerActive) {
                    final List<Offset> pts = _pointerPositions.values.take(2).toList();
                    final Offset focal = (pts[0] + pts[1]) / 2;
                    final double span = (pts[0] - pts[1]).distance;
                    // pan based on focal movement (ms-based)
                    if (_twoStartFocal != null) {
                      final double dx = focal.dx - _twoStartFocal!.dx;
                      final double deltaMs = (dx / math.max(1.0, width)) * startWindowSize;
                      windowStart = startWindowStart - deltaMs;
                      _clampWindow();
                    }
                    // zoom based on span ratio -> snap to 3h/6h/12h/24h
                    if (_twoStartSpan > 0) {
                      final double scale = span / _twoStartSpan;
                      final double proposed = startWindowSize / scale;
                      final List<double> steps = <double>[3, 6, 12, 24].map((h) => h * 3600000.0).toList();
                      double best = steps.first;
                      double bestDelta = (proposed - best).abs();
                      for (final double s in steps) {
                        final double d = (proposed - s).abs();
                        if (d < bestDelta) { best = s; bestDelta = d; }
                      }
                      windowSize = best;
                      // keep right end stable during pinch
                      final double rightEnd = _rightEndMs();
                      windowStart = rightEnd - windowSize;
                      _clampWindow();
                    }
                    setState(() {});
                  }
                },
                onPointerUp: (e) {
                  _pointerPositions.remove(e.pointer);
                  _activePointers = _pointerPositions.length;
                  if (_activePointers < 2) {
                    _twoFingerActive = false;
                    _twoStartFocal = null;
                    _twoStartSpan = 1.0;
                  }
                  setState(() {});
                },
                onPointerCancel: (e) {
                  _pointerPositions.remove(e.pointer);
                  _activePointers = _pointerPositions.length;
                  _twoFingerActive = false;
                  _twoStartFocal = null;
                  _twoStartSpan = 1.0;
                  setState(() {});
                },
                child: const SizedBox.expand(),
              );
            }),
            ),
            // crosshair line at touched index (left inset = 0; Y축은 오버레이로 그림)
            Positioned.fill(
              child: LayoutBuilder(
                builder: (context, c) {
                  _panelWidth = c.maxWidth;
                  if (touchedIndex == null || widget.points.isEmpty) return const SizedBox.shrink();
                  final double width = c.maxWidth;
                  // plot area insets (no extra left margin)
                  const double leftInset = 0;
                  const double rightInset = 0;
                  final double plotWidth = math.max(1.0, width - leftInset - rightInset);
                  final double xMs = widget.points[touchedIndex!.clamp(0, widget.points.length - 1)].time.millisecondsSinceEpoch.toDouble();
                  final double xRatio = (xMs - windowStart) / math.max(1e-6, windowSize);
                  final double x = (leftInset + xRatio * plotWidth).clamp(leftInset, leftInset + plotWidth);
                  final double valueAtCrosshair = widget.points[touchedIndex!.clamp(0, widget.points.length - 1)].value;
                  final Color crossColor = valueAtCrosshair < 70
                      ? Colors.redAccent.withValues(alpha: 0.5)
                      : (valueAtCrosshair > 180 ? Colors.orangeAccent.withValues(alpha: 0.5) : Colors.redAccent.withValues(alpha: 0.5));
                  return Stack(children: [
                    Positioned(
                      left: (x - 0.5).clamp(leftInset, leftInset + plotWidth - 1),
                      top: 0,
                      bottom: 0,
                      child: Container(width: 1, color: crossColor),
                    ),
                    // removed fixed end date labels on x-axis
                    // top badge: glucose value with direction arrow
                    Positioned(
                      left: (x - 72).clamp(leftInset, math.max(leftInset, leftInset + plotWidth - 144)),
                      top: 0, // 16px date stripe + 20px padding
                      child: Builder(builder: (context) {
                        final int i = touchedIndex!.clamp(0, widget.points.length - 1);
                        final double v = widget.points[i].value;
                        final double? prev = i > 0 ? widget.points[i - 1].value : null;
                        final double? next = (i + 1 < widget.points.length) ? widget.points[i + 1].value : null;
                        double delta = 0;
                        if (prev != null) {
                          delta = v - prev;
                        } else if (next != null) {
                          delta = v - next;
                        }
                        final IconData arrow = delta > 0.5
                            ? Icons.arrow_upward
                            : (delta < -0.5 ? Icons.arrow_downward : Icons.horizontal_rule);
                        final Color badgeBg = v < 70
                            ? Colors.red
                            : (v > 180 ? Colors.orange : Theme.of(context).colorScheme.primary);
                        return Material(
                          color: Colors.white,
                          elevation: 2,
                          borderRadius: BorderRadius.circular(16),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(arrow, size: 14, color: Colors.black54),
                                const SizedBox(width: 6),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: badgeBg,
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  child: Text(
                                    v.toStringAsFixed(0),
                                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 12),
                                  ),
                                ),
                                const SizedBox(width: 8),
                                Builder(builder: (context) {
                                  final DateTime tt = widget.points[i].time;
                                  final String hh = tt.hour.toString().padLeft(2, '0');
                                  final String mm = tt.minute.toString().padLeft(2, '0');
                                  return Text('$hh:$mm', style: const TextStyle(color: Colors.black87, fontSize: 11, fontWeight: FontWeight.w600));
                                }),
                              ],
                            ),
                          ),
                        );
                      }),
                    ),
                    // removed: time label under the badge (hh:mm)
                  ]);
                },
              ),
            ),
            // interaction overlay: tap/double-tap/long-press + event taps
            Positioned.fill(
              child: LayoutBuilder(
                builder: (context, c) {
                  return GestureDetector(
                    behavior: HitTestBehavior.translucent,
                    onPanStart: (d) {
                      _oneFingerLastDx = d.localPosition.dx;
                    },
                    onPanUpdate: (d) {
                      // 기본 드래그 모드: 수평 이동 (데이터 표시가 없을 때)
                      if (touchedIndex == null) {
                        // 화면 너비 대비 이동량을 현재 뷰 윈도우 크기에 비례시켜 시간축 속도와 손가락 속도 동기화
                        final double dx = d.localPosition.dx - (_oneFingerLastDx ?? d.localPosition.dx);
                        _oneFingerLastDx = d.localPosition.dx;
                        final int n = math.max(1, widget.points.length - 1);
                        final double maxStart = math.max(0, n - windowSize).toDouble();
                        final double width = c.maxWidth;
                        // dx(픽셀) : width(픽셀) = deltaIndex : windowSize → deltaIndex = dx/width*windowSize
                        final double deltaIndex = (dx / math.max(1.0, width)) * windowSize;
                        double nextStart = (windowStart - deltaIndex);
                        // 우측이 마지막 시각(오늘)일 때 더 이상 진행하지 않음
                        if (nextStart > maxStart) nextStart = maxStart;
                        setState(() => windowStart = nextStart);
                        return;
                      }
                      // 데이터 표시모드에서는 스크럽 이동
                      final int idx = _nearestIndexForDx(d.localPosition.dx, c.maxWidth);
                      setState(() => touchedIndex = idx);
                      widget.onSelectIndex(idx);
                    },
                    onPanEnd: (_) {
                      _oneFingerLastDx = null;
                    },
                    onTapUp: (d) {
                      final Size sz = Size(c.maxWidth, c.maxHeight);
                      final Offset p = d.localPosition;
                      // compute nearest index and its screen x/y (approx y from value)
                      final int idx = _nearestIndexForDx(p.dx, sz.width);
                      final int clamped = idx.clamp(0, widget.points.length - 1);
                      final double v = widget.points[clamped].value;
                      // map to x in plot space
                      // plot inset not needed here as we use nearest index by dx
                      // final double plotWidth = math.max(1.0, sz.width - leftInset - rightInset);
                      // final double ix = clamped.toDouble();
                      // ms-based; index path removed
                    // final double px = (leftInset + xRatio * plotWidth).clamp(leftInset, leftInset + plotWidth);
                      // map to y (value to pixel)
                      final double py = sz.height - (v / widget.maxY * sz.height);
                      // allow only by Y tolerance; X는 제한 없이 가장 가까운 포인트 선택
                      const double tol = 15.0;
                      if ((p.dy - py).abs() <= tol) {
                        setState(() => touchedIndex = clamped);
                        widget.onSelectIndex(clamped);
                      } else {
                        // y축 해당하지 않게 클릭하면 데이터 표시 해제 + 드래그 모드 전환
                        setState(() => touchedIndex = null);
                      }
                    },
                  );
                },
              ),
            ),
            // bottom popup removed; top label shown near crosshair instead
            // removed fixed top-right round box (now list scroll sync only)
            // event markers: icon with gray round badge background
            Positioned.fill(
              child: LayoutBuilder(
                builder: (context, c) {
                  final double width = c.maxWidth;
                  if (widget.events.isEmpty || widget.points.isEmpty) return const SizedBox.shrink();
                  final List<Widget> children = <Widget>[];
                  // final bool isDark = Theme.of(context).brightness == Brightness.dark;
                  // reorder events: 혈당(bloodGlucose) 운동(exercise) 인슐린(insulin) 메모(memo) 식사(meal) 약물(medication)
                  final List<GlucoseEvent> ordered = List<GlucoseEvent>.from(widget.events);
                  int weight(EventType t) {
                    switch (t) {
                      case EventType.bloodGlucose:
                        return 0;
                      case EventType.exercise:
                        return 1;
                      case EventType.insulin:
                        return 2;
                      case EventType.memo:
                        return 3;
                      case EventType.meal:
                        return 4;
                      case EventType.medication:
                        return 5;
                    }
                  }
                  ordered.sort((a, b) => weight(a.type).compareTo(weight(b.type)));
                  for (int i = 0; i < ordered.length; i++) {
                    final int pi = _indexForTime(ordered[i].time);
                  // viewport transform with plot area insets (no left inset)
                  const double leftInset = 0;
                  const double rightInset = 0;
                  final double plotWidth = math.max(1.0, width - leftInset - rightInset);
                  final double tMs = widget.points[pi.clamp(0, widget.points.length - 1)].time.millisecondsSinceEpoch.toDouble();
                  final double xRatio = (tMs - windowStart) / math.max(1e-6, windowSize);
                  final double x = leftInset + xRatio * plotWidth;
                  if (x >= leftInset && x <= leftInset + plotWidth) {
                    children.add(Positioned(
                      // align icons on a bottom row inside plot, not on Y-axis
                      top: 30,
                      left: (x - 16).clamp(leftInset, leftInset + plotWidth - 32),
                      child: _EventBadge(type: ordered[i].type, size: 32),
                    ));
                  }
                  }
                  return Stack(children: children);
                },
              ),
            ),
            // back button (wide mode) placed on top of overlays
            if (widget.isWideMode)
              Positioned(
                top: 8,
                right: 8,
                child: Material(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10),
                  elevation: 2,
                  child: InkWell(
                    borderRadius: BorderRadius.circular(10),
                    onTap: () => Navigator.of(context).pop(),
                    child: const Padding(
                      padding: EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.arrow_back, size: 18),
                          SizedBox(width: 8),
                          Text('Back', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
          ],
        ),
    );
  }

  double _viewportAverage() {
    if (widget.points.isEmpty) return 0;
    final int startIdx = windowStart.ceil().clamp(0, widget.points.length - 1);
    final int endIdx = (windowStart + windowSize).floor().clamp(0, widget.points.length - 1);
    if (endIdx < startIdx) return widget.points.last.value;
    double sum = 0;
    int count = 0;
    for (int i = startIdx; i <= endIdx; i++) {
      sum += widget.points[i].value;
      count++;
    }
    if (count == 0) return 0;
    return sum / count;
  }

  // x-label interval removed (bottom titles hidden)

  int _nearestIndexForDx(double dx, double width) {
    if (widget.points.isEmpty) return 0;
    // match plot insets used in crosshair calculation
    const double leftInset = 0;
    const double rightInset = 0;
    final double plotWidth = math.max(1.0, width - leftInset - rightInset);
    final double clamped = dx.clamp(leftInset, leftInset + plotWidth) - leftInset;
    final double ratio = (clamped / plotWidth).clamp(0.0, 1.0);
    final double tMs = windowStart + ratio * math.max(1e-6, windowSize);
    // 시간 기반으로 가장 가까운 인덱스를 찾음
    int best = 0; int bestDelta = 1 << 30;
    for (int i = 0; i < widget.points.length; i++) {
      final int ms = widget.points[i].time.millisecondsSinceEpoch;
      final int d = (ms - tMs).abs().round();
      if (d < bestDelta) { bestDelta = d; best = i; }
    }
    return best;
  }

  // haptic helper removed (unused)

  // 뷰포트 인덱스(실수) -> 시간 보간 (X축 기반 날짜 스트립에 사용)
  DateTime _timeForIndex(double idx) {
    if (widget.points.isEmpty) return DateTime.now();
    final int n = widget.points.length;
    if (idx <= 0) return widget.points.first.time;
    if (idx >= n - 1) return widget.points.last.time;
    final int i0 = idx.floor();
    final int i1 = idx.ceil();
    final DateTime t0 = widget.points[i0].time;
    final DateTime t1 = widget.points[i1].time;
    final int m0 = t0.millisecondsSinceEpoch;
    final int m1 = t1.millisecondsSinceEpoch;
    final double r = idx - i0;
    final int mi = (m0 + (m1 - m0) * r).round();
    return DateTime.fromMillisecondsSinceEpoch(mi);
  }

  int _indexForTime(DateTime t) {
    int best = 0;
    int bestDelta = 1 << 30;
    for (int i = 0; i < widget.points.length; i++) {
      final int delta = (widget.points[i].time.millisecondsSinceEpoch - t.millisecondsSinceEpoch).abs();
      if (delta < bestDelta) {
        bestDelta = delta;
        best = i;
      }
    }
    return best;
  }

  // nearest-event hit test removed (unused)

}

class _DaySeg {
  _DaySeg(this.start, this.end);
  final DateTime start;
  final DateTime end;
}
