package no.nordicsemi.android.toolbox.profile.manager.repository

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import no.nordicsemi.android.toolbox.profile.parser.rscs.RSCFeatureData
import no.nordicsemi.android.toolbox.profile.parser.rscs.RSCSData
import no.nordicsemi.android.toolbox.profile.parser.rscs.RSCSSettingsUnit
import no.nordicsemi.android.toolbox.profile.data.RSCSServiceData

object RSCSRepository {
    private val _dataMap = mutableMapOf<String, MutableStateFlow<RSCSServiceData>>()

    fun getData(deviceId: String): Flow<RSCSServiceData> {
        return _dataMap.getOrPut(deviceId) { MutableStateFlow(RSCSServiceData()) }
    }

    fun clear(deviceId: String) {
        _dataMap.remove(deviceId)
    }

    fun onRSCSDataChanged(deviceId: String, data: RSCSData) {
        _dataMap[deviceId]?.update { it.copy(data = data) }
    }

    fun updateUnitSettings(deviceId: String, rscsUnitSettings: RSCSSettingsUnit) {
        _dataMap[deviceId]?.update { it.copy(unit = rscsUnitSettings) }
    }

    fun updateRSCSFeatureData(deviceId: String, feature: RSCFeatureData) {
        _dataMap[deviceId]?.update { it.copy(feature = feature) }
    }

}
